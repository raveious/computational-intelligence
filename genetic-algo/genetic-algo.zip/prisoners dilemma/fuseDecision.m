function [decision] = fuseDecision(p1F, p2F)
decision = 3^p1F + p2F;
end

